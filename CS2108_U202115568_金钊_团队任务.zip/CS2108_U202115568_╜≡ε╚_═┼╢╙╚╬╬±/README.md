# Flappy Bird

## 小组介绍

**队名** ：一刻也没有为软件工程哀悼队

**队员**：金钊，彭政，曾世鹏，殷梓达

## 文件目录结构

本项目文件目录如下

├── README.txt
├── cs3410.jar
├── Flappy Bird.circ
├── music_player.circ
├── riscv-probe.jar
├── 团队任务
│   └── 团队任务
│       ├── birdfly.asm
│       ├── birdfly.hex
│       ├── birdfly2.0.asm
│       ├── birdfly2.0.hex
│       ├── birdfly3.0.hex
│       ├── birdfly4.0.hex
│       ├── birdfly5.0.hex
│       ├── birdfly6.0.hex
│       ├── cs3410.jar
│       ├── flippy bird.circ
│       ├── music_player.circ
│       ├── riscv-probe.jar
│       ├── 地图生成.circ
│       └── 小鸟移动.circ
├── 地图生成.circ
├── 小鸟移动
│   ├── birdfly.asm
│   └── birdfly.hex
├── 小鸟移动.circ
├── 小鸟移动逻辑2.circ
└── 背景音乐
    ├── mix.hex
    ├── mysongs.hex
    ├── star_trans.hex
    └── two_tigers.hex

##  使用方法

打开Flappy Bird.circ文件，进入交互电路新，开始使用连续，设置时钟频率为128Hz。点击开始即可开始游戏，点击上按钮控制小鸟移动，游戏结束请直接Ctrl+R复位。